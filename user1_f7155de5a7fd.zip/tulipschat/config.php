<?php
// ===== TulipsChat config =====
return [
    'db_driver'   => 'mysql',          // mysql ya sqlite
    'db_host'     => 'localhost',
    'db_name'     => 'tulipschat',
    'db_user'     => 'root',
    'db_pass'     => '',
    'sqlite_path' => __DIR__ . '/data/chat.sqlite',

    'online_timeout' => 60,            // seconds - itne time me ping na aaye to offline
    'poll_ms'        => 2000,          // chat refresh interval
    'timezone'       => 'Asia/Karachi',
];
