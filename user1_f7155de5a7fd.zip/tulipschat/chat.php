<?php
require __DIR__ . '/core.php';
$me = require_login();
page_head('Chat');
$ann = setting('announcement');
?>
<div class="chat-app">
  <header class="topbar">
    <button class="icon-btn" id="toggleUsers" title="Users">&#9776;</button>
    <strong><?= e(setting('site_name', 'TulipsChat')) ?></strong>
    <nav>
      <a href="profile.php"><img class="av-sm" src="<?= e(avatar_url($me['avatar'])) ?>" alt=""> <?= e($me['username']) ?></a>
      <?php if ($me['role'] === 'admin'): ?><a href="admin/">Admin</a><?php endif; ?>
      <a href="logout.php">Logout</a>
    </nav>
  </header>

  <div class="chat-body">
    <main class="chat-main">
      <?php if ($ann !== ''): ?><div class="announce"><?= e($ann) ?></div><?php endif; ?>
      <div id="messages" class="messages"></div>
      <form id="sendForm" class="send-bar" autocomplete="off">
        <input id="msgInput" maxlength="<?= (int)setting('max_length', '500') ?>" placeholder="Message likhein..." required>
        <button>Send</button>
      </form>
    </main>

    <aside class="userlist" id="userlist">
      <div class="ul-head">Online (<span id="onCount">0</span>)</div>
      <div id="users"></div>
    </aside>
  </div>
</div>

<script>
window.AK = {
  csrf: <?= json_encode(csrf()) ?>,
  me: <?= (int)$me['id'] ?>,
  admin: <?= $me['role'] === 'admin' ? 'true' : 'false' ?>,
  poll: <?= (int)$CFG['poll_ms'] ?>
};
</script>
<script src="assets/chat.js"></script>
<?php page_foot();
